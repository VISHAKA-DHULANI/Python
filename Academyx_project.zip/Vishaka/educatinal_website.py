import streamlit as st
import random

st.set_page_config(
    page_title="Acadeymx",
    page_icon="🎓",
    layout="centered",
    initial_sidebar_state="expanded"
    
)


query_params = st.query_params



page = st.sidebar.radio("Go to:", ["Home", "Register", "Courses",  "Quiz", "Contact","Students","About Us"])
def add_styles():
    st.markdown("""
    <style>
        .title {
            font-family: 'Arial Black', sans-serif;
            color: #4CAF50;
        }
        .subtitle {
            font-family: 'Verdana', sans-serif;
            color: #2E8B57;
        }
        .footer {
            font-size: 12px;
            text-align: center;
            color: gray;
        }
        def add_styles():
        .title {
            font-family: 'Arial Black', sans-serif;
            color: #4CAF50;
        }
        .subtitle {
            font-family: 'Verdana', sans-serif;
            color: #2E8B57;
        }
        .footer {
            font-size: 12px;
            text-align: center;
            color: gray;
        }
        .form-container {
            max-width: 500px;
            margin: 0 auto;
        }
        .content-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
        }
        .content-container > div {
            flex: 1 1 calc(33% - 20px);
            margin: 10px;
        }
        @media (max-width: 768px) {
            .content-container > div {
                flex: 1 1 100%;
            }
        }
    </style>
    """, unsafe_allow_html=True)
add_styles()

students_data = []

if page == "Home":
    st.title("🎓 Welcome to Academyx")
    st.logo("image.jpeg.jpg")
    st.subheader("Learn With Us")
    images = [
            "image2.jpeg", "image3.jpeg", "image4.jpeg",
            "image5.jpeg", "image6.jpeg", "images7.jpeg"
        ]

    
    for i in range(0, len(images), 3):
        cols = st.columns(3)  
        for col, img in zip(cols, images[i:i + 3]):
            col.image(img)
    st.write("Start your learning journey today!")
    if st.button("Register Now"):
        st.query_params(page="Register")

    
    

    students = random.randint(1000, 5000)
    courses = random.randint(50, 100)
    st.metric(label="📚 Active Students", value=f"{students}+")
    st.metric(label="📝 Courses Available", value=f"{courses}")
    st.markdown("""
    ### Why Choose Us?
    - **Comprehensive Courses**: Covering a wide range of topics.
    - **Expert Instructors**: Learn from industry professionals.
    - **Interactive Learning**: Engage with quizzes and assignments.
    """)
    st.write("Start your learning journey today!")
    st.write("© 2025 Academyx. All rights reserved.")
    

    


elif page == "Register" or query_params.get("page") == ["Register"]:
    st.title("Register for AcademyX")
    st.markdown('<div class="form-container">', unsafe_allow_html=True)

    with st.form("registration_form"):
        st.subheader("Fill in your details:")
        name = st.text_input("Full Name")
        email = st.text_input("Email Address")
        password = st.text_input("Password", type="password")
        confirm_password = st.text_input("Confirm Password", type="password")
        contact = st.text_input("Contact Number")
        address = st.text_area("Address")

        submitted = st.form_submit_button("Register")
        if submitted:
            if password == confirm_password:
                st.success(f"Thank you {name}! You have successfully registered.")
            else:
                st.error("Passwords do not match. Please try again.")

    st.markdown('</div>', unsafe_allow_html=True)
    st.write("© 2025 Academyx. All rights reserved.")



elif page == "Courses":
    st.title("📚 Courses")
    courses = [
        {"name": "Web Development", "description": "Build modern websites and applications.", "video": "https://youtu.be/HcOc7P5BMi4?si=GuKaBMlCK6Njfz0r"},
        {"name": "Data Science", "description": "Analyze and visualize data effectively.", "video":"https://youtu.be/-ETQ97mXXF0?si=5NhngeNbiArVkLM0"},
        {"name": "Mobile App Development", "description": "Create apps for Android and iOS.", "video":"https://youtu.be/RtSOQXmyoSY?si=rTX7N9QEriQk_xY2"},
        {"name": "Machine Learning", "description": "Learn AI and data modeling.", "video":"https://youtu.be/GwIo3gDZCVQ?si=2b51is4j7NBxJtsN"},
        {"name": "Cybersecurity", "description": "Secure systems and networks.", "video": "https://www.youtube.com/live/lpa8uy4DyMo?si=KqFS1kXFb0mH9rsB"},
        {"name": "Cloud Computing", "description": "Explore scalable computing systems.", "video":"https://youtu.be/EN4fEbcFZ_E?si=H_B7ljV7n48L2hlU"}
    ]

    for course in courses:
        st.subheader(f"📘 {course['name']}")
        st.write(course["description"])
        if "image" in course:
            st.image(course["image"], caption=f"{course['name']} - Learn and Grow!")
        if "video" in course:
            st.video(course["video"])
            st.write("© 2025 Academyx. All rights reserved.")




elif page == "Contact":
    st.title("📞 Get in Touch")
    with st.form("contact_form"):
        name = st.text_input("Your Name")
        email = st.text_input("Your Email")
        contact = st.text_input("Contact", "")
        address = st.text_input("Address", "")
        message = st.text_area("Your Message")
        submitted = st.form_submit_button("Send")
        
        if submitted:
            st.success(f"Thank you {name}, your message has been sent!")
            st.write("© 2025 Academyx. All rights reserved.")
elif page == "Students":
    st.title("Students Who Are Registered")
    if len(students_data) == 0:
        st.write("No students have registered yet.")
    else:
        for student in students_data:
            st.write(f"### {student['Name']}")
            st.write(f"📧 Email: {student['Email']}")
            st.write(f"📱 Contact: {student['Contact']}")
            st.write(f"🏠 Address: {student['Address']}")
            st.write("---")


elif page == "About Us":
    st.title("About Us")
    
    st.write("Welcome to Acadeymx, your go-to platform for interactive and engaging learning. Our mission is to provide high-quality education to everyone, everywhere. We believe that knowledge empowers individuals and communities.")

    st.header("Our Vision")
    st.write("To be a global leader in online education by offering innovative and accessible learning solutions.")
    
    st.write("John Doe: Founder & CEO")
    st.image("aman.jpeg", caption="Meet our amazing team!")
    st.write("Jane Smith: Lead Instructor")
    st.image("sharda.jpeg", caption="Meet our amazing team!")
    st.write("Michael Johnson: Curriculum Developer")
    st.image("developer.jpeg", caption="Meet our amazing team!")
    st.write("© 2025 Academyx. All rights reserved.")


elif page == "Quiz":
    st.title("🎯 Test Your Knowledge")
    
    course = st.selectbox("Select a course to quiz on:", ["Web Development", "Data Science", "Mobile App Development", "Machine Learning", "Cybersecurity", "Cloud Computing"])

    
    if course == "Web Development":
        st.subheader("🖥️ Web Development Quiz")
        questions = [
            ("What does HTML stand for?", ["Hyper Text Markup Language", "High Tech Machine Learning", "Home Tool Markup Language"]),
            ("What is the purpose of CSS?", ["Adding interactivity", "Styling web pages", "Structuring content"]),
            ("Which tag is used to create a hyperlink in HTML?", ["<a>", "<div>", "<p>"]),
            ("What does the 'id' attribute do in HTML?", ["Identifies an element uniquely", "Adds a class", "Changes the text"]),
            ("Which language is used for styling web pages?", ["HTML", "CSS", "JavaScript"]),
            ("What is JavaScript used for?", ["Adding interactivity", "Styling", "Structuring content"]),
            ("Which tag is used to add an image?", ["<img>", "<image>", "<src>"]),
            ("Which CSS property changes text color?", ["color", "font-size", "background-color"]),
            ("Which property in CSS controls the layout of the page?", ["display", "margin", "padding"]),
            ("What is a div tag used for?", ["Creating sections", "Creating links", "Styling text"]),
        ]
        
        score = 0
        for q, options in questions:
            answer = st.radio(q, options)
            if answer == options[0]:
                score += 1
        if st.button("Submit Web Development Quiz"):
            st.success(f"You scored {score}/10!")
        

    
    elif course == "Data Science":
        st.subheader("📊Data Science Quiz")
        questions = [
            ("What is the main library for data manipulation in Python?", ["NumPy", "Pandas", "Matplotlib"]),
            ("What is used to create data visualizations?", ["Pandas", "Matplotlib", "Django"]),
            ("Which library is used for machine learning?", ["NumPy", "Pandas", "Scikit-learn"]),
            ("What is the first step in data analysis?", ["Data cleaning", "Model training", "Data visualization"]),
            ("What is a DataFrame?", ["A two-dimensional array", "A dictionary", "A graph"]),
            ("Which function is used to read a CSV file in pandas?", ["pd.read_csv()", "np.load()", "pd.DataFrame()"]),
            ("What does a histogram display?", ["Frequency of data distribution", "Relationship between variables", "Trends over time"]),
            ("Which of the following is a supervised learning algorithm?", ["K-Means", "Logistic Regression", "DBSCAN"]),
            ("What is the purpose of data normalization?", ["Scaling data", "Reducing data", "Increasing variance"]),
            ("What does the term 'overfitting' refer to?", ["Model is too complex", "Model is too simple", "Model accuracy is low"]),
        ]
        
        score = 0
        for q, options in questions:
            answer = st.radio(q, options)
            if answer == options[0]:
                score += 1
        if st.button("Submit Data Science Quiz"):
            st.success(f"You scored {score}/10!")


    elif course == "Mobile App Development":
        st.subheader("📱Mobile App Development Quiz")
        questions = [
            ("Which framework is commonly used for cross-platform mobile apps?", ["Flutter", "React", "Django"]),
            ("What language is used for native Android development?", ["Swift", "Kotlin", "JavaScript"]),
            ("Which tool is used for Android app development?", ["Xcode", "Android Studio", "Visual Studio Code"]),
            ("What is React Native used for?", ["Creating mobile apps", "Creating websites", "Creating APIs"]),
            ("Which of the following is an iOS programming language?", ["Swift", "Kotlin", "JavaScript"]),
            ("Which mobile platform uses the 'Play Store'?", ["iOS", "Android", "Windows"]),
            ("Which framework is used to build iOS apps?", ["Flutter", "Kotlin", "Swift"]),
            ("Which language is used for cross-platform mobile apps?", ["Java", "Dart", "Python"]),
            ("What is the role of a mobile backend?", ["To store data", "To display content", "To create designs"]),
            ("Which of the following is NOT a mobile development language?", ["HTML", "Swift", "Kotlin"]),
        ]
        
        score = 0
        for q, options in questions:
            answer = st.radio(q, options)
            if answer == options[0]:
                score += 1
        if st.button("Submit Mobile App Development Quiz"):
            st.success(f"You scored {score}/10!")

    
    elif course == "Machine Learning":
        st.subheader("Machine Learning Quiz")
        questions = [
            ("What is the main goal of supervised learning?", ["Predicting labels", "Clustering data", "Dimensionality reduction"]),
            ("Which algorithm is used for classification?", ["Linear Regression", "Decision Trees", "K-Means"]),
            ("What does overfitting mean?", ["The model is too complex", "The model is too simple", "The model performs well on new data"]),
            ("Which library is commonly used for machine learning?", ["NumPy", "Pandas", "Scikit-learn"]),
            ("What is feature engineering?", ["Creating new features", "Normalizing data", "Building models"]),
            ("Which method is used to test a machine learning model?", ["Cross-validation", "Gradient descent", "Normalization"]),
            ("What does the term 'underfitting' refer to?", ["Model is too simple", "Model is too complex", "Model is overfitting"]),
            ("Which of these is a regression algorithm?", ["Linear Regression", "K-Means", "Naive Bayes"]),
            ("What is clustering?", ["Grouping similar data points", "Predicting data", "Classifying data"]),
            ("What is the purpose of the validation set?", ["To train the model", "To test the model", "To tune hyperparameters"]),
        ]
    
        score = 0
        for q, options in questions:
            answer = st.radio(q, options)
            if answer == options[0]:
                score += 1
        if st.button("Submit Machine Learning Quiz"):
            st.success(f"You scored {score}/10!")


    elif course == "Cybersecurity":
        st.subheader("Cybersecurity Quiz")
        
        st.write("Coming soon!")


    elif course == "Cloud Computing":
        st.subheader("Cloud Computing Quiz")
        
        st.write("Coming soon!")
        
        
        

        